<?PHP namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Http\Requests\Backend\__Module__\Create__Module__Request;
use App\Http\Requests\Backend\__Module__\Update__Module__Request;
use App\Repositories\Backend\__Module__\__Module__Contract;

/**
 * Class DashboardController
 * @package App\Http\Controllers\Backend
 */
class __Module__Controller extends Controller {

    /**
     * @param __Module__Contract $__modules__
     */
    public function __construct(__Module__Contract $__modules__) {
        $this->__modules__ = $__modules__;
    }

    /**
     * @return mixed
     */
    public function index() {
        return view('backend.__modules__.index')
            ->with__Modules__($this->__modules__->get__Modules__Paginated(config('access.users.default_per_page')));
    }

    /**
     * @return mixed
     */
    public function create() {
        return view('backend.__modules__.create');
    }

    /**
     * @param Create__Module__Request $request
     * @return mixed
     */
    public function store(Create__Module__Request $request) {
        $this->__modules__->create($request);
        return redirect()->route('admin.__modules__.index')->withFlashSuccess(trans("alerts.__modules__.created"));
    }

    /**
     * @param $id
     * @return mixed
     */
    public function edit($id) {
        $__module__ = $this->__modules__->findOrThrowException($id, true);
        return view('backend.__modules__.edit')->with__Module__($__module__);
    }

    /**
     * @param $id
     * @param Update__Module__Request $request
     * @return mixed
     */
    public function update($id, Update__Module__Request $request) {
        $this->__modules__->update($id, $request->all());
        return redirect()->route('admin.__modules__.index')->withFlashSuccess(trans("alerts.__modules__.updated"));
    }

    /**
     * @param $id
     * @return mixed
     */
    public function destroy($id) {
        $this->__modules__->destroy($id);
        return redirect()->back()->withFlashSuccess(trans("alerts.__modules__.deleted"));
    }

}