<?php

Route::group([
    'middleware' => 'access.routeNeedsPermission',
    'permission' => ['__modules__'],
    'redirect'   => '/',
    'with'       => ['flash_danger', 'You do not have access to do that.']
], function ()
{

    resource('__modules__', '__Module__Controller', ['except' => ['show']]);

});