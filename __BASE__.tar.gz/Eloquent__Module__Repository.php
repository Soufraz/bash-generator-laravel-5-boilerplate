<?php namespace App\Repositories\Backend\__Module__;

use App\__Module__;
use App\Exceptions\GeneralException;

/**
 * Class Eloquent__Module__Repository
 * @package App\Repositories\__Module__
 */
class Eloquent__Module__Repository implements __Module__Contract {


//	public function __construct() {
//	}

	/**
	 * @param $id
	 * @return mixed
	 * @throws GeneralException
	 */
	public function findOrThrowException($id) {
		$__module__ = __Module__::withTrashed()->find($id);

		if (! is_null($__module__)) return $__module__;

		throw new GeneralException('That __module__ does not exist.');
	}

	/**
	 * @param $per_page
	 * @param string $order_by
	 * @param string $sort
	 * @return mixed
	 */
	public function get__Modules__Paginated($per_page, $order_by = 'id', $sort = 'asc') {
		return __Module__::orderBy($order_by, $sort)->paginate($per_page);
	}

	/**
	 * @param $per_page
	 * @return \Illuminate\Pagination\Paginator
	 */
	public function getDeleted__Modules__Paginated($per_page) {
		return __Module__::onlyTrashed()->paginate($per_page);
	}

	/**
	 * @param string $order_by
	 * @param string $sort
	 * @return mixed
	 */
	public function getAll__Modules__($order_by = 'id', $sort = 'asc') {
		return __Module__::orderBy($order_by, $sort)->get();
	}

    /**
     * @param $input
     * @return bool
     * @throws GeneralException
     */
    public function create($input) {
        $__module__ = $this->create__Module__Stub($input);
        if($__module__->save())
            return true;
        throw new GeneralException('There was a problem creating this __module__. Please try again.');
    }

    /**
     * @param $id
     * @param $input
     * @return bool
     * @throws GeneralException
     */
    public function update($id, $input) {
        $__module__ = $this->findOrThrowException($id);

        if ($__module__->update($input)) {
            $__module__->title  = $input['title'];
            $__module__->save();

            return true;
        }

        throw new GeneralException('There was a problem updating this __module__. Please try again.');
    }

    /**
     * @param $id
     * @return bool
     * @throws GeneralException
     */
    public function destroy($id) {
        $__module__ = $this->findOrThrowException($id);
        if ($__module__->delete())
            return true;

        throw new GeneralException("There was a problem deleting this __module__. Please try again.");
    }

    /**
     * @param $input
     * @return mixed
     */
    private function create__Module__Stub($input)
    {
        $__module__ = new __Module__;
        $__module__->title = $input['title'];
        return $__module__;
    }

}