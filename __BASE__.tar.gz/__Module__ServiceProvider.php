<?php namespace App\Providers;

use Illuminate\Support\ServiceProvider;

/**
 * Class __Module__ServiceProvider
 * @package App\Providers
 */
class __Module__ServiceProvider extends ServiceProvider
{

    /**
     * Register the service provider.
     *
     * @return void
     */
    public function register()
    {
        $this->registerBindings();
    }

    /**
     * Register service provider bindings
     */
    public function registerBindings() {
        $this->app->bind(
            'App\Repositories\Backend\__Module__\__Module__Contract',
            'App\Repositories\Backend\__Module__\Eloquent__Module__Repository'
        );
    }
}